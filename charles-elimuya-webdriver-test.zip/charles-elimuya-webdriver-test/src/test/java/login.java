import static org.junit.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class login {

	//static WebDriver driver;

	
	@Test
	public void login() throws InterruptedException {
		System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir")+"/drivers/geckodriver.exe"); // This locates the browser driver
		WebDriver driver = new FirefoxDriver();   //Initialize firefox and opens firefox browser
		
		driver.manage().window().maximize();    //This maximizes the browser window
		
		driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);    // This tells webriver not to timout while page is loading until after 20 seconds
		
		driver.get("http://zola.zola-fleet-pr-585.zolaelectric.com/");  //This launches the url
		
		driver.findElement(By.id("user_email")).sendKeys("charles.elimuya@gmail.com");     //Enters user email
		
		driver.findElement(By.id("user_password")).sendKeys("password");  // Enters password
		
		driver.findElement(By.name("commit")).click();   //clicks the sign in button
		
		String PerformanceIcon = driver.findElement(By.linkText("Perfomance")).getText();  //This gets the text of Performance Icon
		
		assertEquals(PerformanceIcon,"Perfomance"); //This verifies that the text gotten from the icon above is equal to "Performance". hence ensuring that we are on the Performance page   
		
		Thread.sleep(5000);  //Waits for 5 seconds to allow us see the page.
		
		
		driver.quit();  // Closes the browser
		
	}

}
